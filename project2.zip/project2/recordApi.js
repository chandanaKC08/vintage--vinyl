import axios from "axios";

const API = "http://localhost:5000/api/records";

export const getRecords = () => axios.get(API);