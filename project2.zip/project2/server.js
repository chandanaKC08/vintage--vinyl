import express from "express";
import dotenv from "dotenv";
import cors from "cors";

import connectDB from "./config/db.js";
import recordRoutes from "./routes/recordRoutes.js";
import artistRoutes from "./routes/artistRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import contactRoutes from "./routes/contactRoutes.js";


dotenv.config();

const app = express(); // ✅ MUST BE FIRST

// middleware
app.use(cors());
app.use(express.json());

// routes
app.use("/api/records", recordRoutes);
app.use("/api/artists", artistRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/contact", contactRoutes);


// database
connectDB();

// test route
app.get("/", (req, res) => {
  res.send("Vintage Vinyl API Running");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});