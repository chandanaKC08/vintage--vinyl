import React, { useState } from "react";
import axios from "axios";

function Auth({ setPage }) {
  const [isLogin, setIsLogin] = useState(true);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

 const handleSubmit = async () => {
  try {
    setError("");
    setSuccess("");

    const url = isLogin
      ? "http://localhost:5000/api/auth/login"
      : "http://localhost:5000/api/auth/register";

    const res = await axios.post(
      url,
      isLogin
        ? { email, password }
        : { name, email, password }
    );

    if (res.data.token) {
      localStorage.setItem("token", res.data.token);
    }

    setSuccess(isLogin ? "Login successful 🎧" : "Account created 🎉");

    setPage("home");

  } catch (err) {
    setError(err.response?.data?.message || "Something went wrong");
  }
};

  return (
    <div className="auth-container">

      {/* LEFT IMAGE SIDE */}
      <div className="auth-left">
        <h1>Vintage Vinyl </h1>
          <h2>🎵</h2>
        <p>Feel the sound of classics</p>
      </div>

      {/* RIGHT SIDE */}
      <div className="auth-right">

      <h1>{isLogin ? "Login" : "Sign Up"}</h1>


        {!isLogin && (
         <input
           type="text"
           name="name"
           placeholder="Full Name"
           value={name}
           onChange={(e) => setName(e.target.value)}
         />
       )}

        <input
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleSubmit}>
          {isLogin ? "Login →" : "Create Account →"}
        </button>

        {/* TOGGLE */}
        <p className="link" onClick={() => setIsLogin(!isLogin)}>
          {isLogin ? "Create new account" : "Already have account? Login"}
        </p>

        {/* BACK */}
        <div className="back-button">
          <button className="nav-btn" onClick={() => setPage("landing")}>
            ← Back
          </button>
        </div>

        {/* MESSAGES */}
        {error && <p style={{ color: "#5c2eb1", marginTop: "10px" }}>{error}</p>}
        {success && <p style={{ color: "lightgreen", marginTop: "10px" }}>{success}</p>}

      </div>

    </div>
  );
}

export default Auth;