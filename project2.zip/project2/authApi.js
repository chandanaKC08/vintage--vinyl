import axios from "axios";

const API = "http://localhost:5000/api/auth";

// existing
export const registerUser = (data) => axios.post(`${API}/register`, data);
export const loginUser = (data) => axios.post(`${API}/login`, data);

// NEW OTP APIs
export const sendOtp = (data) => axios.post(`${API}/send-otp`, data);
export const verifyOtp = (data) => axios.post(`${API}/verify-otp`, data);