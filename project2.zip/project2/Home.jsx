import React from "react";

function Home({ setPage }) {
  return (
    <div className="home-page">
    

      {/* MUSIC CATEGORIES */}
      <section id="Home" className="music-types">

        <h2>Explore Music Genres</h2>

        <div className="genre-grid">

          
          <div className="genre-card">
            <h3 className="genre-title">Indie Pop</h3>
            <img src="https://imgs.search.brave.com/GdvE6FphC8I69LeCi5Or27awZsTxMJmDJPZ8frwUjn4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9zdG9y/YWdlLmdob3N0Lmlv/L2MvNjAvNzAvNjA3/MDQyMzAtMjI1Zi00/ZTFlLTk3YjAtNDZh/YjM4ZmJjMDhkL2Nv/bnRlbnQvaW1hZ2Vz/LzIwMjUvMTEvaW1n/LTIzNDk0ODMxMi5q/cGc" alt="indies"/>
            <p>Fresh independent artists and viral hits</p>
          </div>

          <div className="genre-card">
            <h3 className="genre-title">K-Pop</h3>
            <img src="https://imgs.search.brave.com/Hgw2a_I0TZCkLVIioXGVOs8195F0BBhPME10llw7Df0/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93aW1n/LmhlcmFsZGNvcnAu/Y29tL25ld3MvY21z/LzIwMjYvMDIvMjAv/bmV3cy1wLnYxLjIw/MjYwMjIwLmY1MzYx/YjY2NDE3ZDQzZThh/Mzg3OTk5ZjllMzc2/Y2Q1X1QxLmpwZz90/eXBlPWgmaD0yNDA" alt="kpop comeback 2026"/>
            <p>Latest idol comebacks and chart toppers</p>
          </div>

          <div className="genre-card">
            <h3 className="genre-title">T-pop</h3>
            <img src="https://imgs.search.brave.com/g0zGIAlJbWLiv459RvLnBeIeldymufXmpLlh9VRlitA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5zdWFyYS5jb20v/cGljdHVyZXMvNjUz/eDM2Ni8yMDI0LzEy/LzE2LzI2ODc0LWVt/cGF0LWFuZ2dvdGEt/amFzcGVyLmpwZw" alt="Thai classics"></img>
            <p>Classic guitar legends and new bands</p>
          </div>

          <div className="genre-card">
            <h3 className="genre-title">J-pop</h3>
            <img src="https://imgs.search.brave.com/4Kq_TxlaLqDIxHEWCQbgDOFH9cZ61C5KnS-L5Jk-Ay0/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJhY2Nlc3Mu/Y29tL2Z1bGwvMjc0/MzA5NC5qcGc" alt="J-rocks"></img>
            <p>Smooth timeless music and vinyl classics</p>
          </div>

        </div>

      </section>


      {/* RECENT MUSIC NEWS */}
      <section className="music-news">

        <h2>Recent Music News</h2>

        <div className="news-card">
          <h3>K-Pop Comeback</h3>
          <p>Major K-Pop groups release new albums this month.</p>
        </div>

        <div className="news-card">
          <h3>Vinyl Revival</h3>
          <p>Vinyl sales reach record highs again worldwide.</p>
        </div>

        <div className="news-card">
          <h3>Indie Artists Rising</h3>
          <p>Independent musicians dominate streaming charts.</p>
        </div>

        </section>
        <div className="back-button">
        <button className="nav-btn" onClick={() => setPage("landing")}>← Back</button>
        </div>

    </div>
  );
}

export default Home;