import React, { useEffect, useState } from "react";
import bg from "../assets/bg.jpg";
import { getRecords } from "../api/recordApi";
import { imageMap } from "../utils/imageMap.js";
import Rating from "../components/Rating";
import axios from "axios";


function Records({ setPage }) {
  const [records, setRecords] = useState([]);
  const [genre, setGenre] = useState("All");
  const [search, setSearch] = useState("");
  
const toggleFavorite = async (id) => {
  try {
    await axios.patch(`http://localhost:5000/api/records/${id}/favorite`);

    // update UI immediately
    setRecords((prev) =>
      prev.map((rec) =>
        rec._id === id ? { ...rec, favorite: !rec.favorite } : rec
      )
    );
  } catch (err) {
    console.log(err);
  }
};

  useEffect(() => {
    fetchRecords();
  }, []);

  const fetchRecords = async () => {
    try {
      const res = await getRecords();
      setRecords(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  const filteredRecords = records.filter((record) => {
    const matchSearch =
      record.title.toLowerCase().includes(search.toLowerCase()) ||
      record.artist.toLowerCase().includes(search.toLowerCase());

    const matchGenre =
      genre === "All" ||
      record.genre?.trim().toLowerCase() === genre.toLowerCase()

    return matchSearch && matchGenre;
  });

  return (
    <div
      className="records-page"
      style={{
        backgroundImage: `url(${bg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "100vh",
      }}
    >
      <div className="genre-link">
        <h1>Vinyl Records Collection 🎸</h1>

        {/* 🔍 SEARCH BAR */}
        <input
          type="text"
          placeholder="Search records or artists..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-bar"
        />

        <br></br>

        {/* GENRE BUTTONS */}
        <button onClick={() => setGenre("Rock")}>Rock</button>
        <button onClick={() => setGenre("Pop")}>Pop</button>
        <button onClick={() => setGenre("Jazz")}>Jazz</button>
        <button onClick={() => setGenre("All")}>All</button>
      </div>

      {/* FILTER TEXT */}
      <h3 style={{ color: "white", marginLeft: "20px" }}>
        Showing: {genre}
      </h3>

      {/* RECORD GRID */}
      <div className="record-grid">
        {filteredRecords.map((record) => (
          <div key={record._id} className="record-card">
            <img
              src={imageMap[record.imageKey] || "https://via.placeholder.com/150"}
              alt={record.title}
            />
            <h3>{record.title}</h3>
            <p>{record.artist}</p>
            <p>{record.genre}</p>
            <p>₹{record.price}</p>
            <Rating recordId={record._id} />

              {/* ❤️ Favorite Heart */}
            <span
              className="favorite-heart"
              onClick={() => toggleFavorite(record._id)}
              style={{
              color: record.favorite ? "red" : "gray",
              cursor: "pointer",
              fontSize: "22px"
            }}
          >
                ❤
            </span>
          </div>
        ))}
      </div>

      <div className="back-button">
        <button className="nav-btn" onClick={() => setPage("landing")}>
          ← Back
        </button>
      </div>
    </div>
  );
}

export default Records;