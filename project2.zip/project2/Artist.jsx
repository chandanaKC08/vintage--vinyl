import React, { useEffect, useState } from "react";
import { getArtists } from "../api/artistApi";
import { imageMap } from "../utils/imageMap.js";

function Artists({ setPage }) {

  const [artists, setArtists] = useState([]);
  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("All");

  useEffect(() => {
    fetchArtists();
  }, []);

  const fetchArtists = async () => {
    try {
      const res = await getArtists();
      setArtists(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  const filteredArtists = artists.filter((artist) => {

    const matchSearch =
      artist?.name?.toLowerCase().includes(search.toLowerCase());

    const matchGenre =
      genre === "All" ||
      artist?.genre?.toLowerCase() === genre.toLowerCase();

    return matchSearch && matchGenre;
  });

  return (
    <div className="artists-page">

      <h1>🎤 Legendary Artists</h1>

      {/* SEARCH */}
      <input
        type="text"
        placeholder="Search artists..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="search-bar"
      />

      <br/>

      {/* GENRE FILTER BUTTONS */}
      <div className="genre-link">
        <button onClick={() => setGenre("Rock")}>Rock</button>
        <button onClick={() => setGenre("Pop")}>Pop</button>
        <button onClick={() => setGenre("Jazz")}>Jazz</button>
        <button onClick={() => setGenre("All")}>All</button>
      </div>

      {/* FILTER TEXT */}
      <h3>Showing: {genre}</h3>
      <br></br>

      {/* ARTIST GRID */}
      <div className="artist-grid">

        {filteredArtists.map((artist) => (

          <div key={artist._id} className="artist-card">

  <h3 className="artist-name">{artist.name}</h3>

  <img
    src={
      imageMap[artist.imageKey] ||
      "https://via.placeholder.com/150"
    }
    alt={artist.name}
  />

  <p><b>Started:</b> {artist.started}</p>
  <p>{artist.bio}</p>

</div>

        ))}

      </div>

      <button className="nav-btn" onClick={() => setPage("landing")}>
        ⬅ Back
      </button>

    </div>
  );
}

export default Artists;