import React, { useState } from "react";
import axios from "axios";

function Contact({ setPage }) {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const handleSubmit = async () => {
    try {
      await axios.post("http://localhost:5000/api/contact", {
        name,
        email,
        message
      });

      setSuccessMsg("Message sent successfully 🎉");

     // optional: clear message after 3 seconds
        setTimeout(() => {
        setSuccessMsg("");
    }, 3000);

      // clear form
      setName("");
      setEmail("");
      setMessage("");

    } catch (err) {
      console.log(err);
      setSuccessMsg("Failed to send message");
    }
  };

  return (
    <div className="contact-page">

      <h1>📞 Contact Vintage Vinyl</h1>

      <div className="contact-container">

        <div className="contact-form">

          <h2>Send us a Message</h2>

          <input
            type="text"
            placeholder="Your Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <input
            type="email"
            placeholder="Your Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <textarea
            placeholder="Your Message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />

          <button className="nav-btn" onClick={handleSubmit}>
            Send Message
          </button>

        </div>

         {successMsg && (
             <p className="success-message">
             {successMsg}
           </p>
         )}


        <div className="contact-info">
          <h2>Store Information</h2>

          <p><b>📍 Address:</b> Vintage Vinyl Store, Music Street, Bangalore</p>
          <p><b>📞 Phone:</b> +91 98765 43210</p>
          <p><b>📧 Email:</b> vintagevinyl@email.com</p>
          <p><b>🕒 Hours:</b> Mon - Sat | 10 AM - 8 PM</p>

        </div>

      </div>

      <button className="nav-btn" onClick={() => setPage("landing")}>
        ⬅ Back
      </button>

    </div>
  );
}

export default Contact;