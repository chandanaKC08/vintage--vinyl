/*Record page images*/
import led from "../assets/led.jpg";
import beatles from "../assets/beatles.jpg";
import pinkfloyd from "../assets/pinkfloyd.jpg";

import mj from "../assets/mj.jpg";
import madonna from "../assets/madonna.jpg";
import taylor from "../assets/taylor.jpg";

import miles from "../assets/miles.jpg";
import louis from "../assets/louis.jpg";
import coltrane from "../assets/coltrane.jpg";

import bts from "../assets/bts.jpg";
import ado from "../assets/ado.jpg";
import queen from "../assets/queen.jpg";

import arctic from "../assets/arctic.jpg";
import hancock from "../assets/hancock.jpg";

/* Artist page images */
import darkside from "../assets/darkside.jpg";
import zeppelin4 from "../assets/zeppelin4.jpg";
import opera from "../assets/opera.jpg";

import thriller from "../assets/thriller.jpg";
import t1989 from "../assets/1989.jpg";
import bts7 from "../assets/bts7.jpg";

import kindofblue from "../assets/kindofblue.jpg";
import headhunter from "../assets/headhunter.jpg";
import timeout from "../assets/timeout.jpg";

export const imageMap = {
  led,
  beatles,
  pinkfloyd,
  mj,
  madonna,
  taylor,
  miles,
  louis,
  coltrane,
  bts,
  ado,
  queen,
  arctic,
  hancock,

  darkside,
  zeppelin4,
  opera,
  thriller,
  "1989": t1989,
  bts7,
  kindofblue,
  headhunter,
  timeout
};