import express from "express";
import Record from "../models/Record.js";

const router = express.Router();

// CREATE record
router.post("/", async (req, res) => {
  try {
    const record = await Record.create(req.body);
    res.status(201).json(record);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET all records
router.get("/", async (req, res) => {
  try {
    const records = await Record.find();
    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// UPDATE record (PUT)
router.put("/:id", async (req, res) => {
  try {
    const updatedRecord = await Record.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedRecord) {
      return res.status(404).json({ message: "Record not found" });
    }

    res.json(updatedRecord);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// PARTIAL UPDATE (PATCH)
router.patch("/:id", async (req, res) => {
  try {
    const updatedRecord = await Record.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedRecord) {
      return res.status(404).json({ message: "Record not found" });
    }

    res.json(updatedRecord);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// DELETE record
router.delete("/:id", async (req, res) => {
  try {
    const deletedRecord = await Record.findByIdAndDelete(req.params.id);

    if (!deletedRecord) {
      return res.status(404).json({ message: "Record not found" });
    }

    res.json({ message: "Record deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// RATE a record
router.post("/:id/rate", async (req, res) => {
  try {
    const { value } = req.body;

    const record = await Record.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    record.ratings.push({ value });

    const total = record.ratings.reduce((sum, r) => sum + r.value, 0);
    record.averageRating = total / record.ratings.length;

    await record.save();

    res.json(record);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// TOGGLE FAVORITE
router.patch("/:id/favorite", async (req, res) => {
  try {

    const record = await Record.findById(req.params.id);

    record.favorite = !record.favorite;

    await record.save();

    res.json(record);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;