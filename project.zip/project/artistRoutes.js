import express from "express";
import Artist from "../models/Artist.js";

const router = express.Router();

// GET all artists
router.get("/", async (req, res) => {
  try {
    const artists = await Artist.find();
    res.json(artists);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// CREATE artist
router.post("/", async (req, res) => {
  try {
    const artist = await Artist.create(req.body);
    res.status(201).json(artist);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// UPDATE record (PUT)
router.put("/:id", async (req, res) => {
  try {
    const updatedArtist= await Record.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedArtist) {
      return res.status(404).json({ message: "Artist not found" });
    }

    res.json(updatedArtist);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// PARTIAL UPDATE (PATCH)
router.patch("/:id", async (req, res) => {
  try {
    const updatedArtist = await Record.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedArtist) {
      return res.status(404).json({ message: "Artist not found" });
    }

    res.json(updatedArtist);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// DELETE record
router.delete("/:id", async (req, res) => {
  try {
    const deletedArtist = await Record.findByIdAndDelete(req.params.id);

    if (!deletedArtist) {
      return res.status(404).json({ message: "Artist not found" });
    }

    res.json({ message: "Artist deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;