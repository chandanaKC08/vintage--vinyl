import mongoose from "mongoose";

const artistSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    genre: {
      type: String,
      required: true, // Rock / Pop / Jazz
    },
    imageKey: {
      type: String,
      required: true
    },
    started: {
      type: String,
    },
    bio: {
      type: String,
    },
  },
  { timestamps: true }
);

const Artist = mongoose.model("Artist", artistSchema);

export default Artist;