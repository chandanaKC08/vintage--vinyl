import mongoose from "mongoose";

const recordSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    artist: {
      type: String,
      required: true,
    },
    genre: {
      type: String,
      required: true,
    },
    year: {
      type: Number,
    },
    price: {
      type: Number,
      required: true,
    },
    imageKey: {
     type: String,
     required: true
    },
     ratings: [
    {
      value: Number
    }
  ],

  averageRating: {
    type: Number,
    default: 0
  },
  favorite: {
    type: Boolean,
    default: false
  }
  },
  { timestamps: true }
);

const Record = mongoose.model("Record", recordSchema);

export default Record;